<?php
require_once "model/Genre.php";

class GenreController {
    private $model;

    public function __construct($db)
    {
        $this->model = new Genre($db);
    }

    public function index()
    {
        $genres = $this->model->getAll();
        include "view/genre/index.php";
    }

    public function create()
    {
        include "view/genre/create.php";
    }

    public function store()
    {
        $data = [
            'nama' => $_POST['nama']
        ];
        $this->model->create($data);
        header("Location: index.php?action=genre_index");
    }

    public function edit($id)
    {
        $genre = $this->model->getById($id);
        include "view/genre/edit.php";
    }

    public function update()
    {
        $data = [
            'nama' => $_POST['nama']
        ];
        $id = $_POST['id'];
        $this->model->update($id, $data);
        header("Location: index.php?action=genre_index");
    }

    public function delete($id)
    {
        $this->model->delete($id);
        header("Location: index.php?action=genre_index");
    }
}
?>
