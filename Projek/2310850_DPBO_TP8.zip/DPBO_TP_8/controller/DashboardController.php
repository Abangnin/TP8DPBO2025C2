<?php
class DashboardController {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function index() {
        $result = $this->conn->query("SELECT 
            mhs.nama AS mahasiswa, 
            mhs.nim, 
            mhs.jurusan, 
            mhs.phone, 
            musik.judul AS musik, 
            musik.artis AS artis, 
            genre.nama AS genre 
        FROM kesukaan_musik km 
        JOIN mahasiswa mhs ON km.mahasiswa_id = mhs.id 
        JOIN musik ON km.musik_id = musik.id 
        JOIN genre ON musik.genre_id = genre.id");
    
        include "view/dashboard.php";
    }
    
}
?>
