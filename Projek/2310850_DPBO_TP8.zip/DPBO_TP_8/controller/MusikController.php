<?php
require_once "model/Musik.php";
require_once "model/Genre.php";

class MusikController {
    private $model;
    private $genreModel;

    public function __construct($db)
    {
        $this->model = new Musik($db);
        $this->genreModel = new Genre($db);
    }

    public function index()
    {
        $musik = $this->model->getAll();
        include "view/musik/index.php";
    }

    public function create()
    {
        $genres = $this->genreModel->getAll();
        include "view/musik/create.php";
    }

    public function store()
    {
        $data = [
            'judul' => $_POST['judul'],
            'artis' => $_POST['artis'],
            'genre_id' => $_POST['genre_id']
        ];
        $this->model->create($data);
        header("Location: index.php?action=musik_index");
    }

    public function edit($id)
    {
        $musik = $this->model->getById($id);
        $genres = $this->genreModel->getAll();
        include "view/musik/edit.php";
    }

    public function update()
    {
        $data = [
            'judul' => $_POST['judul'],
            'artis' => $_POST['artis'],
            'genre_id' => $_POST['genre_id']
        ];
        $id = $_POST['id'];
        $this->model->update($id, $data);
        header("Location: index.php?action=musik_index");
    }

    public function delete($id)
    {
        $this->model->delete($id);
        header("Location: index.php?action=musik_index");
    }
}
?>
