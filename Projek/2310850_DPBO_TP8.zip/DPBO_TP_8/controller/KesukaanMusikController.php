<?php
require_once "model/KesukaanMusik.php";
require_once "model/Student.php";
require_once "model/Musik.php";

class KesukaanMusikController {
    private $model;
    private $studentModel;
    private $musikModel;

    public function __construct($db)
    {
        $this->model = new KesukaanMusik($db);
        $this->studentModel = new Student($db);
        $this->musikModel = new Musik($db);
    }

    public function index()
    {
        $data = $this->model->getAll();
        include "view/kesukaan/index.php";
    }

    public function create()
    {
        $students = $this->studentModel->getAll();
        $musik = $this->musikModel->getAll();
        include "view/kesukaan/create.php";
    }

    public function store()
    {
        $data = [
            'mahasiswa_id' => $_POST['mahasiswa_id'],
            'musik_id' => $_POST['musik_id']
        ];
        $this->model->create($data);
        header("Location: index.php?action=kesukaan_index");
    }

    public function edit($id)
    {
        $entry = $this->model->getById($id);
        $students = $this->studentModel->getAll();
        $musik = $this->musikModel->getAll();
        include "view/kesukaan/edit.php";
    }

    public function update()
    {
        $data = [
            'mahasiswa_id' => $_POST['mahasiswa_id'],
            'musik_id' => $_POST['musik_id']
        ];
        $id = $_POST['id'];
        $this->model->update($id, $data);
        header("Location: index.php?action=kesukaan_index");
    }

    public function delete($id)
    {
        $this->model->delete($id);
        header("Location: index.php?action=kesukaan_index");
    }
}
?>
