<?php
require_once "model/Student.php";

class StudentController {
    private $model;

    public function __construct($db)
    {
        $this->model = new Student($db);
    }

    public function index()
    {
        $students = $this->model->getAll();
        include "view/student/index.php";
    }

    public function create()
    {
        include "view/student/create.php";
    }

    public function store()
    {
        $data = [
            'nama' => $_POST['name'],
            'nim' => $_POST['nim'],
            'jurusan' => $_POST['jurusan'],
            'phone' => $_POST['phone']
        ];
        $this->model->create($data);
        header("Location: index.php?action=student_index");
    }

    public function edit($id)
    {
        $student = $this->model->getById($id);
        include "view/student/edit.php";
    }

    public function update()
    {
        $data = [
            'nama' => $_POST['name'],
            'nim' => $_POST['nim'],
            'jurusan' => $_POST['jurusan'],
            'phone' => $_POST['phone']
        ];
        $id = $_POST['id'];
        $this->model->update($id, $data);
        header("Location: index.php?action=student_index");
    }

    public function delete($id)
    {
        $this->model->delete($id);
        header("Location: index.php?action=student_index");
    }
}
?>