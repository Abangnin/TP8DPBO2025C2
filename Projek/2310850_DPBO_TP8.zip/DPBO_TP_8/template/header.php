<?php 
$action = $_GET['action'] ?? 'dashboard';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard Kesukaan Musik Mahasiswa</title>
  <link href="bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
  <a class="navbar-brand" href="index.php?action=dashboard_index">Dashboard</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="index.php?action=student_index">Mahasiswa</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?action=genre_index">Genre</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?action=musik_index">Musik</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?action=kesukaan_index">Kesukaan Musik</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container">