<?php
require_once "config/connection.php";
require_once "controller/StudentController.php";
require_once "controller/GenreController.php";
require_once "controller/MusikController.php";
require_once "controller/KesukaanMusikController.php";
require_once "controller/DashboardController.php";

// Tangkap parameter 'action' dari URL, default ke 'dashboard'
$action = $_GET['action'] ?? 'dashboard';

// Inisialisasi controller
$dashboardController = new DashboardController($conn);

// Routing controller berdasarkan action
switch (true) {
    // Dashboard
    case $action === 'dashboard_index':
        $dashboardController->index();
        break;

    // Student
    case $action === 'student_index':
        (new StudentController($conn))->index();
        break;
    case $action === 'student_create':
        (new StudentController($conn))->create();
        break;
    case $action === 'student_store':
        (new StudentController($conn))->store();
        break;
    case $action === 'student_edit':
        (new StudentController($conn))->edit($_GET['id']);
        break;
    case $action === 'student_update':
        (new StudentController($conn))->update();
        break;
    case $action === 'student_delete':
        (new StudentController($conn))->delete($_GET['id']);
        break;

    // Genre
    case $action === 'genre_index':
        (new GenreController($conn))->index();
        break;
    case $action === 'genre_create':
        (new GenreController($conn))->create();
        break;
    case $action === 'genre_store':
        (new GenreController($conn))->store();
        break;
    case $action === 'genre_edit':
        (new GenreController($conn))->edit($_GET['id']);
        break;
    case $action === 'genre_update':
        (new GenreController($conn))->update();
        break;
    case $action === 'genre_delete':
        (new GenreController($conn))->delete($_GET['id']);
        break;

    // Musik
    case $action === 'musik_index':
        (new MusikController($conn))->index();
        break;
    case $action === 'musik_create':
        (new MusikController($conn))->create();
        break;
    case $action === 'musik_store':
        (new MusikController($conn))->store();
        break;
    case $action === 'musik_edit':
        (new MusikController($conn))->edit($_GET['id']);
        break;
    case $action === 'musik_update':
        (new MusikController($conn))->update();
        break;
    case $action === 'musik_delete':
        (new MusikController($conn))->delete($_GET['id']);
        break;

    // Kesukaan Musik
    case $action === 'kesukaan_index':
        (new KesukaanMusikController($conn))->index();
        break;
    case $action === 'kesukaan_create':
        (new KesukaanMusikController($conn))->create();
        break;
    case $action === 'kesukaan_store':
        (new KesukaanMusikController($conn))->store();
        break;
    case $action === 'kesukaan_edit':
        (new KesukaanMusikController($conn))->edit($_GET['id']);
        break;
    case $action === 'kesukaan_update':
        (new KesukaanMusikController($conn))->update();
        break;
    case $action === 'kesukaan_delete':
        (new KesukaanMusikController($conn))->delete($_GET['id']);
        break;

    // Default ke dashboard kalau action nggak dikenali
    default:
        $dashboardController->index();
        break;
}
?>