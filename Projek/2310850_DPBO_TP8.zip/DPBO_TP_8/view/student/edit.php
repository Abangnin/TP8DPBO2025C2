<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Edit Mahasiswa</h2>
  <form action="index.php?action=student_update" method="post">
    <input type="hidden" name="id" value="<?= $student['id'] ?>">
    <div class="mb-3">
      <label>Nama</label>
      <input type="text" name="name" class="form-control" value="<?= $student['nama'] ?>" required>
    </div>
    <div class="mb-3">
      <label>NIM</label>
      <input type="text" name="nim" class="form-control" value="<?= $student['nim'] ?>" required>
    </div>
    <div class="mb-3">
      <label>Jurusan</label>
      <input type="text" name="jurusan" class="form-control" value="<?= $student['jurusan'] ?>" required>
    </div>
    <div class="mb-3">
      <label>Phone</label>
      <input type="text" name="phone" class="form-control" value="<?= $student['phone'] ?>" required>
    </div>
    <button type="submit" class="btn btn-success">Update</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </form>
</div>

<?php 
include "template/footer.php"; 
?>