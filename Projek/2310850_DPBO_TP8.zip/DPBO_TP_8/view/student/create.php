<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Tambah Mahasiswa</h2>
  <form action="index.php?action=student_store" method="post">
    <div class="mb-3">
      <label>Nama</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>NIM</label>
      <input type="text" name="nim" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Jurusan</label>
      <input type="text" name="jurusan" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Phone</label>
      <input type="text" name="phone" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="index.php?action=student_index" class="btn btn-secondary">Kembali</a>

  </form>
</div>

<?php 
include "template/footer.php"; 
?>