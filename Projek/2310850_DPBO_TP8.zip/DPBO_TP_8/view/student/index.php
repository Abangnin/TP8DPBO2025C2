<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Daftar Mahasiswa</h2>
  <a href="index.php?action=student_create" class="btn btn-primary mb-3">Tambah Mahasiswa</a>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>NIM</th>
        <th>Jurusan</th>
        <th>Phone</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $students->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['nama'] ?></td>
          <td><?= $row['nim'] ?></td>
          <td><?= $row['jurusan'] ?></td>
          <td><?= $row['phone'] ?></td>
          <td>
            <a href="index.php?action=student_edit&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="index.php?action=student_delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin?')">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php 
include "template/footer.php"; 
?>