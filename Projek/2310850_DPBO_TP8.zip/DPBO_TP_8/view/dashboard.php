<?php 
include "template/header.php"; 
?>

<div class="container mt-4">
    <h2>Data Kesukaan Musik Mahasiswa</h2>
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Mahasiswa</th>
                <th>NIM</th>
                <th>Jurusan</th>
                <th>Phone</th>
                <th>Musik Favorit</th>
                <th>Artis</th>
                <th>Genre</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$no}</td>
                    <td>{$row['mahasiswa']}</td>
                    <td>{$row['nim']}</td>
                    <td>{$row['jurusan']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['musik']}</td>
                    <td>{$row['artis']}</td>
                    <td>{$row['genre']}</td>
                </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</div>

<?php 
include "template/footer.php"; 
?>
