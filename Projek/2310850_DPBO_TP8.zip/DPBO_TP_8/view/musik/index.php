<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Daftar Musik</h2>
  <a href="index.php?action=musik_create" class="btn btn-primary mb-3">Tambah Musik</a>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Judul</th>
        <th>Artis</th>
        <th>Genre</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $musik->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['judul'] ?></td>
          <td><?= $row['artis'] ?></td>
          <td><?= $row['genre_nama'] ?></td>
          <td>
            <a href="index.php?action=musik_edit&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="index.php?action=musik_delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin?')">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php 
include "template/footer.php"; 
?>
