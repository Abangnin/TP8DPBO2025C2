<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Tambah Musik</h2>
  <form action="index.php?action=musik_store" method="POST">
    <div class="mb-3">
      <label>Judul</label>
      <input type="text" name="judul" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Artis</label>
      <input type="text" name="artis" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Genre</label>
      <select name="genre_id" class="form-control" required>
        <?php while ($row = $genres->fetch_assoc()): ?>
          <option value="<?= $row['id'] ?>"><?= $row['nama'] ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
  </form>
</div>

<?php 
include "template/footer.php"; 
?>
