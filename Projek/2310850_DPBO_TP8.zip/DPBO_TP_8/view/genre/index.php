<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Daftar Genre</h2>
  <a href="index.php?action=genre_create" class="btn btn-primary mb-3">Tambah Genre</a>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nama Genre</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $genres->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['nama'] ?></td>
          <td>
            <a href="index.php?action=genre_edit&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="index.php?action=genre_delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin?')">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php 
include "template/footer.php"; 
?>
