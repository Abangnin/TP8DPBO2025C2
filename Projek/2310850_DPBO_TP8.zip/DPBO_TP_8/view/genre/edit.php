<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Edit Genre</h2>
  <form action="index.php?action=genre_update" method="POST">
    <input type="hidden" name="id" value="<?= $genre['id'] ?>">
    <div class="mb-3">
      <label>Nama Genre</label>
      <input type="text" name="nama" class="form-control" value="<?= $genre['nama'] ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
  </form>
</div>

<?php 
include "template/footer.php"; 
?>
