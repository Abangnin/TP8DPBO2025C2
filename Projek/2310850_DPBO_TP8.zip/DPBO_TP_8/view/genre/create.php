<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Tambah Genre</h2>
  <form action="index.php?action=genre_store" method="POST">
    <div class="mb-3">
      <label>Nama Genre</label>
      <input type="text" name="nama" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
  </form>
</div>

<?php 
include "template/footer.php"; 
?>
