<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Edit Data Kesukaan</h2>
  <form action="index.php?action=kesukaan_update" method="POST">
    <input type="hidden" name="id" value="<?= $entry['id'] ?>">
    <div class="mb-3">
      <label>Mahasiswa</label>
      <select name="mahasiswa_id" class="form-control" required>
        <?php while ($row = $students->fetch_assoc()): ?>
          <option value="<?= $row['id'] ?>" <?= ($entry['mahasiswa_id'] == $row['id']) ? 'selected' : '' ?>>
            <?= $row['nama'] ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Musik</label>
      <select name="musik_id" class="form-control" required>
        <?php while ($row = $musik->fetch_assoc()): ?>
          <option value="<?= $row['id'] ?>" <?= ($entry['musik_id'] == $row['id']) ? 'selected' : '' ?>>
            <?= $row['judul'] ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
  </form>
</div>

<?php 
include "template/footer.php"; 
?>
