<?php 
include "template/header.php"; 
?>

<div class="container my-4">
  <h2>Data Kesukaan Musik Mahasiswa</h2>
  <a href="index.php?action=kesukaan_create" class="btn btn-primary mb-3">Tambah Data Kesukaan</a>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nama Mahasiswa</th>
        <th>Judul Musik</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $data->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['student_name'] ?></td>
          <td><?= $row['musik_title'] ?></td>
          <td>
            <a href="index.php?action=kesukaan_edit&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="index.php?action=kesukaan_delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin?')">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php 
include "template/footer.php"; 
?>
