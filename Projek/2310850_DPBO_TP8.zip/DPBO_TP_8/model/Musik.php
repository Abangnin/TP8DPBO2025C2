<?php
class Musik {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getAll() {
        return $this->conn->query("SELECT musik.*, genre.nama AS genre_nama 
            FROM musik 
            JOIN genre ON musik.genre_id = genre.id");
    }

    public function getById($id) {
        return $this->conn->query("SELECT * FROM musik WHERE id=$id")->fetch_assoc();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO musik (judul, artis, genre_id) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $data['judul'], $data['artis'], $data['genre_id']);
        return $stmt->execute();
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE musik SET judul=?, artis=?, genre_id=? WHERE id=?");
        $stmt->bind_param("ssii", $data['judul'], $data['artis'], $data['genre_id'], $id);
        return $stmt->execute();
    }

    public function delete($id) {
        return $this->conn->query("DELETE FROM musik WHERE id=$id");
    }
}
?>
