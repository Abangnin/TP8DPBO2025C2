<?php
class KesukaanMusik {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getAll() {
        return $this->conn->query("SELECT km.*, mhs.nama AS student_name, m.judul AS musik_title 
            FROM kesukaan_musik km 
            JOIN mahasiswa mhs ON km.mahasiswa_id = mhs.id 
            JOIN musik m ON km.musik_id = m.id");
    }

    public function getById($id) {
        return $this->conn->query("SELECT * FROM kesukaan_musik WHERE id=$id")->fetch_assoc();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO kesukaan_musik (mahasiswa_id, musik_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $data['mahasiswa_id'], $data['musik_id']);
        return $stmt->execute();
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE kesukaan_musik SET mahasiswa_id=?, musik_id=? WHERE id=?");
        $stmt->bind_param("iii", $data['mahasiswa_id'], $data['musik_id'], $id);
        return $stmt->execute();
    }

    public function delete($id) {
        return $this->conn->query("DELETE FROM kesukaan_musik WHERE id=$id");
    }
}
?>
