<?php
class Genre {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getAll() {
        return $this->conn->query("SELECT * FROM genre");
    }

    public function getById($id) {
        return $this->conn->query("SELECT * FROM genre WHERE id=$id")->fetch_assoc();
    }

    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO genre (nama) VALUES (?)");
        $stmt->bind_param("s", $data['nama']);
        return $stmt->execute();
    }

    public function update($id, $data) {
        $stmt = $this->conn->prepare("UPDATE genre SET nama=? WHERE id=?");
        $stmt->bind_param("si", $data['nama'], $id);
        return $stmt->execute();
    }

    public function delete($id) {
        return $this->conn->query("DELETE FROM genre WHERE id=$id");
    }
}
?>
