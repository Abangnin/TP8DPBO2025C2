<?php
class Student {
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function getAll()
    {
        return $this->conn->query("SELECT * FROM mahasiswa");
    }

    public function getById($id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM mahasiswa WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function create($data)
    {
        $sql = "INSERT INTO mahasiswa (nama, nim, jurusan, phone) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssss", $data['nama'], $data['nim'], $data['jurusan'], $data['phone']);
        return $stmt->execute();
    }

    public function update($id, $data)
    {
        $sql = "UPDATE mahasiswa SET nama = ?, nim = ?, jurusan = ?, phone = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssi", $data['nama'], $data['nim'], $data['jurusan'], $data['phone'], $id);
        return $stmt->execute();
    }

    public function delete($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM mahasiswa WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>
